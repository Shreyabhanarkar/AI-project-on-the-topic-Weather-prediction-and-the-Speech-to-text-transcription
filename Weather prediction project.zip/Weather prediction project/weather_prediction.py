import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error

# Load the dataset
data = pd.read_csv('weather_data.csv')
data['Date'] = pd.to_datetime(data['Date'])

# Plot temperature over time
plt.figure(figsize=(10, 5))
plt.plot(data['Date'], data['Temperature'], marker='o')
plt.title('Temperature Over Time')
plt.xlabel('Date')
plt.ylabel('Temperature (°C)')
plt.grid()
plt.savefig("screenshots/temperature_trend.png")
plt.show()

# Prepare data for prediction
X = data[['Humidity', 'WindSpeed']]  # Features
y = data['Temperature']              # Target

# Train/test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Linear regression model
model = LinearRegression()
model.fit(X_train, y_train)

# Predictions
y_pred = model.predict(X_test)

# Evaluation
rmse = mean_squared_error(y_test, y_pred, squared=False)
print(f"Root Mean Square Error (RMSE): {rmse:.2f}")

# Predict future temperature
future = pd.DataFrame({'Humidity': [30, 32, 35], 'WindSpeed': [2, 3, 2]})
future_predictions = model.predict(future)

print("\nFuture Temperature Predictions:")
for i, temp in enumerate(future_predictions):
    print(f"Day {i+1}: {temp:.2f} °C")
