# Weather Data Analysis and Prediction 🌤️

This project analyzes weather trends and predicts future temperature based on historical data using Linear Regression.

Files
- `weather_data.csv`: Sample dataset
- `weather_prediction.py`: Main script
- `screenshots/`: Graph images
- `README.md`: Project info

Features
- Visualizes temperature over time
- Predicts temperature using Humidity and Wind Speed
- Uses Linear Regression model
- Prints RMSE and future predictions

Libraries Required
```bash
pip install pandas matplotlib seaborn scikit-learn
